@extends('layouts.admin-dashboard')
@section('title')
    Dashboard : Home
@endsection
@section('sidebar-dashboard')
    active
@endsection

@section('main-content')
    <h1>Dashoard</h1>
@endsection
